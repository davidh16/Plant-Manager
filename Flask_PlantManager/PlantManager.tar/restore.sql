--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "PlantManager";
--
-- Name: PlantManager; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "PlantManager" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "PlantManager" OWNER TO postgres;

\connect "PlantManager"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: workers_tasks; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA workers_tasks;


ALTER SCHEMA workers_tasks OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: machines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.machines (
    machine_id integer NOT NULL,
    machine character varying,
    needs_frequent_maintenance boolean NOT NULL,
    frequency_of_maintenance integer,
    in_need_of_maintenance boolean,
    last_maintenance timestamp without time zone,
    last_maintained_by character varying
);


ALTER TABLE public.machines OWNER TO postgres;

--
-- Name: dummy_stroj_part_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dummy_stroj_part_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dummy_stroj_part_id_seq OWNER TO postgres;

--
-- Name: dummy_stroj_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dummy_stroj_part_id_seq OWNED BY public.machines.machine_id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    username character varying NOT NULL,
    name character varying NOT NULL,
    surname character varying NOT NULL,
    job character varying NOT NULL,
    access_level character varying NOT NULL,
    date_of_employment date,
    phone_number character varying NOT NULL,
    income integer,
    last_login timestamp without time zone,
    last_logout timestamp without time zone,
    last_warehouse_entrance timestamp without time zone,
    last_warehouse_exit timestamp without time zone,
    password character varying NOT NULL,
    date_of_birth date,
    public_id character varying
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse (
    part_id integer NOT NULL,
    part character varying NOT NULL,
    quantity integer NOT NULL,
    critical_quantity integer NOT NULL,
    brand character varying NOT NULL,
    supplier character varying NOT NULL,
    catalogue_number integer NOT NULL,
    type character varying,
    model character varying,
    last_administration timestamp without time zone,
    last_administration_by character varying
);


ALTER TABLE public.warehouse OWNER TO postgres;

--
-- Name: skladište_part_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."skladište_part_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."skladište_part_id_seq" OWNER TO postgres;

--
-- Name: skladište_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."skladište_part_id_seq" OWNED BY public.warehouse.part_id;


--
-- Name: zaposlenici_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zaposlenici_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zaposlenici_id_seq OWNER TO postgres;

--
-- Name: zaposlenici_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zaposlenici_id_seq OWNED BY public.employees.id;


--
-- Name: boroš; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks."boroš" (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks."boroš" OWNER TO postgres;

--
-- Name: boroš_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks."boroš_task_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks."boroš_task_id_seq" OWNER TO postgres;

--
-- Name: boroš_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks."boroš_task_id_seq" OWNED BY workers_tasks."boroš".task_id;


--
-- Name: ivand; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.ivand (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.ivand OWNER TO postgres;

--
-- Name: ivand1; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.ivand1 (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.ivand1 OWNER TO postgres;

--
-- Name: ivand1_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.ivand1_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.ivand1_task_id_seq OWNER TO postgres;

--
-- Name: ivand1_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.ivand1_task_id_seq OWNED BY workers_tasks.ivand1.task_id;


--
-- Name: ivand_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.ivand_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.ivand_task_id_seq OWNER TO postgres;

--
-- Name: ivand_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.ivand_task_id_seq OWNED BY workers_tasks.ivand.task_id;


--
-- Name: lukap; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.lukap (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.lukap OWNER TO postgres;

--
-- Name: lukap_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.lukap_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.lukap_task_id_seq OWNER TO postgres;

--
-- Name: lukap_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.lukap_task_id_seq OWNED BY workers_tasks.lukap.task_id;


--
-- Name: mislava; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.mislava (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.mislava OWNER TO postgres;

--
-- Name: mislava_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.mislava_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.mislava_task_id_seq OWNER TO postgres;

--
-- Name: mislava_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.mislava_task_id_seq OWNED BY workers_tasks.mislava.task_id;


--
-- Name: mislavm; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.mislavm (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.mislavm OWNER TO postgres;

--
-- Name: mislavm_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.mislavm_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.mislavm_task_id_seq OWNER TO postgres;

--
-- Name: mislavm_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.mislavm_task_id_seq OWNED BY workers_tasks.mislavm.task_id;


--
-- Name: vedranb; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.vedranb (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.vedranb OWNER TO postgres;

--
-- Name: vedranb_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.vedranb_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.vedranb_task_id_seq OWNER TO postgres;

--
-- Name: vedranb_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.vedranb_task_id_seq OWNED BY workers_tasks.vedranb.task_id;


--
-- Name: zvonimirn; Type: TABLE; Schema: workers_tasks; Owner: postgres
--

CREATE TABLE workers_tasks.zvonimirn (
    task_id integer NOT NULL,
    machine character varying,
    date_of_assignment timestamp without time zone,
    date_of_completion timestamp without time zone,
    status character varying,
    description text,
    description_of_work text,
    machine_id integer
);


ALTER TABLE workers_tasks.zvonimirn OWNER TO postgres;

--
-- Name: zvonimirn_task_id_seq; Type: SEQUENCE; Schema: workers_tasks; Owner: postgres
--

CREATE SEQUENCE workers_tasks.zvonimirn_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE workers_tasks.zvonimirn_task_id_seq OWNER TO postgres;

--
-- Name: zvonimirn_task_id_seq; Type: SEQUENCE OWNED BY; Schema: workers_tasks; Owner: postgres
--

ALTER SEQUENCE workers_tasks.zvonimirn_task_id_seq OWNED BY workers_tasks.zvonimirn.task_id;


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.zaposlenici_id_seq'::regclass);


--
-- Name: machines machine_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.machines ALTER COLUMN machine_id SET DEFAULT nextval('public.dummy_stroj_part_id_seq'::regclass);


--
-- Name: warehouse part_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse ALTER COLUMN part_id SET DEFAULT nextval('public."skladište_part_id_seq"'::regclass);


--
-- Name: boroš task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks."boroš" ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks."boroš_task_id_seq"'::regclass);


--
-- Name: ivand task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.ivand ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.ivand_task_id_seq'::regclass);


--
-- Name: ivand1 task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.ivand1 ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.ivand1_task_id_seq'::regclass);


--
-- Name: lukap task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.lukap ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.lukap_task_id_seq'::regclass);


--
-- Name: mislava task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.mislava ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.mislava_task_id_seq'::regclass);


--
-- Name: mislavm task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.mislavm ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.mislavm_task_id_seq'::regclass);


--
-- Name: vedranb task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.vedranb ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.vedranb_task_id_seq'::regclass);


--
-- Name: zvonimirn task_id; Type: DEFAULT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.zvonimirn ALTER COLUMN task_id SET DEFAULT nextval('workers_tasks.zvonimirn_task_id_seq'::regclass);


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, username, name, surname, job, access_level, date_of_employment, phone_number, income, last_login, last_logout, last_warehouse_entrance, last_warehouse_exit, password, date_of_birth, public_id) FROM stdin;
\.
COPY public.employees (id, username, name, surname, job, access_level, date_of_employment, phone_number, income, last_login, last_logout, last_warehouse_entrance, last_warehouse_exit, password, date_of_birth, public_id) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: machines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.machines (machine_id, machine, needs_frequent_maintenance, frequency_of_maintenance, in_need_of_maintenance, last_maintenance, last_maintained_by) FROM stdin;
\.
COPY public.machines (machine_id, machine, needs_frequent_maintenance, frequency_of_maintenance, in_need_of_maintenance, last_maintenance, last_maintained_by) FROM '$$PATH$$/3674.dat';

--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse (part_id, part, quantity, critical_quantity, brand, supplier, catalogue_number, type, model, last_administration, last_administration_by) FROM stdin;
\.
COPY public.warehouse (part_id, part, quantity, critical_quantity, brand, supplier, catalogue_number, type, model, last_administration, last_administration_by) FROM '$$PATH$$/3672.dat';

--
-- Data for Name: boroš; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks."boroš" (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks."boroš" (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3686.dat';

--
-- Data for Name: ivand; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.ivand (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.ivand (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3688.dat';

--
-- Data for Name: ivand1; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.ivand1 (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.ivand1 (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: lukap; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.lukap (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.lukap (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3676.dat';

--
-- Data for Name: mislava; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.mislava (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.mislava (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3680.dat';

--
-- Data for Name: mislavm; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.mislavm (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.mislavm (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3682.dat';

--
-- Data for Name: vedranb; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.vedranb (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.vedranb (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3684.dat';

--
-- Data for Name: zvonimirn; Type: TABLE DATA; Schema: workers_tasks; Owner: postgres
--

COPY workers_tasks.zvonimirn (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM stdin;
\.
COPY workers_tasks.zvonimirn (task_id, machine, date_of_assignment, date_of_completion, status, description, description_of_work, machine_id) FROM '$$PATH$$/3678.dat';

--
-- Name: dummy_stroj_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dummy_stroj_part_id_seq', 2, true);


--
-- Name: skladište_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."skladište_part_id_seq"', 1, true);


--
-- Name: zaposlenici_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zaposlenici_id_seq', 99, true);


--
-- Name: boroš_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks."boroš_task_id_seq"', 1, false);


--
-- Name: ivand1_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.ivand1_task_id_seq', 1, false);


--
-- Name: ivand_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.ivand_task_id_seq', 1, false);


--
-- Name: lukap_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.lukap_task_id_seq', 2, true);


--
-- Name: mislava_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.mislava_task_id_seq', 1, false);


--
-- Name: mislavm_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.mislavm_task_id_seq', 1, false);


--
-- Name: vedranb_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.vedranb_task_id_seq', 1, false);


--
-- Name: zvonimirn_task_id_seq; Type: SEQUENCE SET; Schema: workers_tasks; Owner: postgres
--

SELECT pg_catalog.setval('workers_tasks.zvonimirn_task_id_seq', 1, false);


--
-- Name: machines machines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.machines
    ADD CONSTRAINT machines_pkey PRIMARY KEY (machine_id);


--
-- Name: warehouse skladište_kataloški_broj_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse
    ADD CONSTRAINT "skladište_kataloški_broj_key" UNIQUE (catalogue_number);


--
-- Name: warehouse skladište_naziv_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse
    ADD CONSTRAINT "skladište_naziv_key" UNIQUE (part);


--
-- Name: warehouse skladište_part_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse
    ADD CONSTRAINT "skladište_part_id_key" UNIQUE (part_id);


--
-- Name: employees zaposlenici_broj_telefona_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT zaposlenici_broj_telefona_key UNIQUE (phone_number);


--
-- Name: employees zaposlenici_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT zaposlenici_pkey PRIMARY KEY (id);


--
-- Name: employees zaposlenici_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT zaposlenici_user_id_key UNIQUE (username);


--
-- Name: boroš boroš_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks."boroš"
    ADD CONSTRAINT "boroš_pkey" PRIMARY KEY (task_id);


--
-- Name: ivand1 ivand1_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.ivand1
    ADD CONSTRAINT ivand1_pkey PRIMARY KEY (task_id);


--
-- Name: ivand ivand_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.ivand
    ADD CONSTRAINT ivand_pkey PRIMARY KEY (task_id);


--
-- Name: lukap lukap_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.lukap
    ADD CONSTRAINT lukap_pkey PRIMARY KEY (task_id);


--
-- Name: mislava mislava_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.mislava
    ADD CONSTRAINT mislava_pkey PRIMARY KEY (task_id);


--
-- Name: mislavm mislavm_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.mislavm
    ADD CONSTRAINT mislavm_pkey PRIMARY KEY (task_id);


--
-- Name: vedranb vedranb_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.vedranb
    ADD CONSTRAINT vedranb_pkey PRIMARY KEY (task_id);


--
-- Name: zvonimirn zvonimirn_pkey; Type: CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.zvonimirn
    ADD CONSTRAINT zvonimirn_pkey PRIMARY KEY (task_id);


--
-- Name: boroš boroš_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks."boroš"
    ADD CONSTRAINT "boroš_machine_id_fkey" FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: ivand1 ivand1_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.ivand1
    ADD CONSTRAINT ivand1_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: ivand ivand_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.ivand
    ADD CONSTRAINT ivand_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: lukap lukap_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.lukap
    ADD CONSTRAINT lukap_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: mislava mislava_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.mislava
    ADD CONSTRAINT mislava_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: mislavm mislavm_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.mislavm
    ADD CONSTRAINT mislavm_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: vedranb vedranb_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.vedranb
    ADD CONSTRAINT vedranb_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- Name: zvonimirn zvonimirn_machine_id_fkey; Type: FK CONSTRAINT; Schema: workers_tasks; Owner: postgres
--

ALTER TABLE ONLY workers_tasks.zvonimirn
    ADD CONSTRAINT zvonimirn_machine_id_fkey FOREIGN KEY (machine_id) REFERENCES public.machines(machine_id);


--
-- PostgreSQL database dump complete
--

